// import vue from 'vue'
// var events = require('events')
// var eventsEmitter = new events.EventEmitter()
// export function createVueObj(vueClass, attr, event) {
//   let vueObj = vue.extend(vueClass)
// }
