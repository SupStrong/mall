const dataPage = () => import('@/views/data/data')

export default {
  path: '/index',
  name: 'data',
  component: dataPage,
  meta: {
    auth: true,
    title: '首页',
    icon: 'el-icon-share',
    notMenu: true,
    keepAlive: true,
  },
}
