const dataPage = () => import('@/views/data/data1')

export default {
  path: '/indexs',
  name: 'data',
  component: dataPage,
  meta: {
    auth: true,
    title: '首页一',
    icon: 'el-icon-share',
    notMenu: true,
    keepAlive: true,
  },
}
