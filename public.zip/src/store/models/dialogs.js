export default {
  bill_list_confirm: false,
  bill_list_export: false,
  bill_list_menu: false,
  bill_list_objection: false,
  confirmation_order: false,
  billDetailsDialog: false,
  dissentDialog: false,
  goodsListDialog: false,
  serviceListDialog: false,
  addSendAddress: false
}
